<x-user::layout>
    <x-slot name="page_slug">analytics</x-slot>
    <div class="shadow-md rounded-lg p-4">
        <h1 class="text-2xl font-bold text-gray-900 mb-2">Analytics</h1>
    </div>
</x-user::layout>