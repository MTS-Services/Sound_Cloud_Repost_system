// import './bootstrap';

import './jquery';
import './datatable';
import './sweetalert2';
import './axios';
import './filepond';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
